import { Component, OnInit } from '@angular/core';
import { RestApiService } from '../rest-api.service';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {
  taskList:any=[];
  constructor(private service:RestApiService) { }

  ngOnInit() {
    this.service.getTasks().subscribe(data=> {
      for (let i = 0; i < data.length; i++) {
        this.taskList.push({id:data[i].id,name:data[i].title,type:data[i].status.label,hrForecast:data[i].nbHoursForecast,hrReal:data[i].nbHoursReal,devs:data[i].developers});
      }
    })
  }

  patchTasks(action:string,id:number){
    this.service.patchTask(action,id).subscribe(data=> {
    })
    window.location.reload()
  }
}