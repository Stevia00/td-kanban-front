import { Component, OnInit } from '@angular/core';
import { RestApiService } from '../rest-api.service';

@Component({
  selector: 'app-developers',
  templateUrl: './developers.component.html',
  styleUrls: ['./developers.component.css']
})
export class DevelopersComponent implements OnInit {
  devList:any=[];
  constructor(private service:RestApiService) { }

  ngOnInit() {
    this.service.getDevs().subscribe(data=> {
      for (let i = 0; i < data.length; i++) {
        this.devList.push({id:data[i].id,firstName:data[i].firstname,lastName:data[i].lastname,startContract:data[i].startContract});
      }
    })
  }
}