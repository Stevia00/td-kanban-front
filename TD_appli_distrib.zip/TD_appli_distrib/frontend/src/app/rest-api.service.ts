import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RestApiService {
  constructor(private http: HttpClient) { }

  getDevs(){
    return this.http.get<developers[]>("http://localhost:8080/" +'developers');
  }
  getTasks() {
    return this.http.get<tasks[]>("http://localhost:8080/" +'tasks');
  }
  patchTask(move:string,id:number){
    return this.http.patch<tasks>("http://localhost:8080/" +'tasks/'+id,{"action": move})
  };
}

interface developers{
  id:number  
  firstname:string
  lastname:string
  startContract:string
}

interface tasks{
  id:number
  title:string  
  status: {
    id: number,
    label: string
  }
  nbHoursForecast:number
  nbHoursReal:number
  developers:string
}