import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddTaskComponent } from './add-task/add-task.component';
import { DevelopersComponent } from './developers/developers.component';
import { TasksComponent } from './tasks/tasks.component';

const routes: Routes =[
  {path: '',redirectTo:'tasks',pathMatch:'full'},
  {path: 'developers',component:DevelopersComponent},
  {path: 'tasks',component:TasksComponent},
  {path: 'newTask',component:AddTaskComponent},
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
