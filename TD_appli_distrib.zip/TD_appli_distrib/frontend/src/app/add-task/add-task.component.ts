import { Component, OnInit } from '@angular/core';
import { RestApiService } from '../rest-api.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {
  status=[
    "Todo",
    "Doing",
    "Test",
    "Done",
  ];
  developersList:any=[];
  Title:any;
  hrForecast:any;
  hrReal:any;

  constructor(private service:RestApiService) { }
  ngOnInit(){
    this.service.getDevs().subscribe(data=> {
      for (let i = 0; i < data.length; i++) {
        this.developersList.push({id:data[i].id,firstName:data[i].firstname,lastName:data[i].lastname,startContract:data[i].startContract});
      }
    })
  }

  send(){
    window.location.reload()
  }
}
