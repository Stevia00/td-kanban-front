# kanban-back

[Swagger] http://localhost:8080/swagger-ui.html

[Actuator] http://localhost:8080/actuator